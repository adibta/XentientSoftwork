##Aplikasi Administrasi Mentoring##

- Aplikasi ini dibuat menggunakan Visual Studio dengan bahasa C#
- Untuk solution terdapat pada folder ini dengan nama "Mentoring.sln"
- Untuk executable file dapat diakses di \Mentoring\bin\Release\Mentoring.exe

Created by Adibta Triantama

Powered by Xentient Softwork
