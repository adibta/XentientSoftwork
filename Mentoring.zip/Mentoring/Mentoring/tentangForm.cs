﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mentoring
{
    public partial class tentangForm : Form
    {
        public tentangForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = true;
           // base.OnFormClosing(e);
            Hide();

        }
    }
}
