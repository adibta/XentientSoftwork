﻿namespace Mentoring
{
    partial class mainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainMenu));
            this.mentorComboBox = new System.Windows.Forms.ComboBox();
            this.mentorLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.izinBox4 = new System.Windows.Forms.TextBox();
            this.izinBox3 = new System.Windows.Forms.TextBox();
            this.izinBox2 = new System.Windows.Forms.TextBox();
            this.izinBox1 = new System.Windows.Forms.TextBox();
            this.izin4CheckBox = new System.Windows.Forms.CheckBox();
            this.izin3CheckBox = new System.Windows.Forms.CheckBox();
            this.izin2CheckBox = new System.Windows.Forms.CheckBox();
            this.izin1CheckBox = new System.Windows.Forms.CheckBox();
            this.hadir4CheckBox = new System.Windows.Forms.CheckBox();
            this.hadir3CheckBox = new System.Windows.Forms.CheckBox();
            this.hadir2CheckBox = new System.Windows.Forms.CheckBox();
            this.hadir1CheckBox = new System.Windows.Forms.CheckBox();
            this.mentee4Box = new System.Windows.Forms.TextBox();
            this.mentee3Box = new System.Windows.Forms.TextBox();
            this.mentee2Box = new System.Windows.Forms.TextBox();
            this.mentee1Box = new System.Windows.Forms.TextBox();
            this.tanggalLabel = new System.Windows.Forms.Label();
            this.beritaAcaraLabel = new System.Windows.Forms.Label();
            this.beritaAcaraBox = new System.Windows.Forms.RichTextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.TahunComboBox = new System.Windows.Forms.ComboBox();
            this.bulanComboBox = new System.Windows.Forms.ComboBox();
            this.hariComboBox = new System.Windows.Forms.ComboBox();
            this.laporanButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sistemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.keluarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tentangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mentorComboBox
            // 
            this.mentorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mentorComboBox.FormattingEnabled = true;
            this.mentorComboBox.Items.AddRange(new object[] {
            "Arya Albana",
            "Imam Santoso"});
            this.mentorComboBox.Location = new System.Drawing.Point(12, 45);
            this.mentorComboBox.Name = "mentorComboBox";
            this.mentorComboBox.Size = new System.Drawing.Size(197, 21);
            this.mentorComboBox.TabIndex = 0;
            this.mentorComboBox.SelectedIndexChanged += new System.EventHandler(this.mentorComboBox_SelectedIndexChanged);
            // 
            // mentorLabel
            // 
            this.mentorLabel.AutoSize = true;
            this.mentorLabel.Location = new System.Drawing.Point(12, 29);
            this.mentorLabel.Name = "mentorLabel";
            this.mentorLabel.Size = new System.Drawing.Size(71, 13);
            this.mentorLabel.TabIndex = 3;
            this.mentorLabel.Text = "Nama Mentor";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.izinBox4);
            this.groupBox1.Controls.Add(this.izinBox3);
            this.groupBox1.Controls.Add(this.izinBox2);
            this.groupBox1.Controls.Add(this.izinBox1);
            this.groupBox1.Controls.Add(this.izin4CheckBox);
            this.groupBox1.Controls.Add(this.izin3CheckBox);
            this.groupBox1.Controls.Add(this.izin2CheckBox);
            this.groupBox1.Controls.Add(this.izin1CheckBox);
            this.groupBox1.Controls.Add(this.hadir4CheckBox);
            this.groupBox1.Controls.Add(this.hadir3CheckBox);
            this.groupBox1.Controls.Add(this.hadir2CheckBox);
            this.groupBox1.Controls.Add(this.hadir1CheckBox);
            this.groupBox1.Controls.Add(this.mentee4Box);
            this.groupBox1.Controls.Add(this.mentee3Box);
            this.groupBox1.Controls.Add(this.mentee2Box);
            this.groupBox1.Controls.Add(this.mentee1Box);
            this.groupBox1.Location = new System.Drawing.Point(15, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(473, 164);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mentee";
            // 
            // izinBox4
            // 
            this.izinBox4.Location = new System.Drawing.Point(309, 124);
            this.izinBox4.Name = "izinBox4";
            this.izinBox4.Size = new System.Drawing.Size(148, 20);
            this.izinBox4.TabIndex = 15;
            // 
            // izinBox3
            // 
            this.izinBox3.Location = new System.Drawing.Point(309, 91);
            this.izinBox3.Name = "izinBox3";
            this.izinBox3.Size = new System.Drawing.Size(148, 20);
            this.izinBox3.TabIndex = 14;
            // 
            // izinBox2
            // 
            this.izinBox2.Location = new System.Drawing.Point(309, 53);
            this.izinBox2.Name = "izinBox2";
            this.izinBox2.Size = new System.Drawing.Size(148, 20);
            this.izinBox2.TabIndex = 13;
            // 
            // izinBox1
            // 
            this.izinBox1.Location = new System.Drawing.Point(309, 19);
            this.izinBox1.Name = "izinBox1";
            this.izinBox1.Size = new System.Drawing.Size(148, 20);
            this.izinBox1.TabIndex = 12;
            // 
            // izin4CheckBox
            // 
            this.izin4CheckBox.AutoSize = true;
            this.izin4CheckBox.Location = new System.Drawing.Point(261, 127);
            this.izin4CheckBox.Name = "izin4CheckBox";
            this.izin4CheckBox.Size = new System.Drawing.Size(42, 17);
            this.izin4CheckBox.TabIndex = 11;
            this.izin4CheckBox.Text = "Izin";
            this.izin4CheckBox.UseVisualStyleBackColor = true;
            this.izin4CheckBox.CheckedChanged += new System.EventHandler(this.izinChecked);
            // 
            // izin3CheckBox
            // 
            this.izin3CheckBox.AutoSize = true;
            this.izin3CheckBox.Location = new System.Drawing.Point(261, 93);
            this.izin3CheckBox.Name = "izin3CheckBox";
            this.izin3CheckBox.Size = new System.Drawing.Size(42, 17);
            this.izin3CheckBox.TabIndex = 10;
            this.izin3CheckBox.Text = "Izin";
            this.izin3CheckBox.UseVisualStyleBackColor = true;
            this.izin3CheckBox.CheckedChanged += new System.EventHandler(this.izinChecked);
            // 
            // izin2CheckBox
            // 
            this.izin2CheckBox.AutoSize = true;
            this.izin2CheckBox.Location = new System.Drawing.Point(261, 57);
            this.izin2CheckBox.Name = "izin2CheckBox";
            this.izin2CheckBox.Size = new System.Drawing.Size(42, 17);
            this.izin2CheckBox.TabIndex = 9;
            this.izin2CheckBox.Text = "Izin";
            this.izin2CheckBox.UseVisualStyleBackColor = true;
            this.izin2CheckBox.CheckedChanged += new System.EventHandler(this.izinChecked);
            // 
            // izin1CheckBox
            // 
            this.izin1CheckBox.AutoSize = true;
            this.izin1CheckBox.Location = new System.Drawing.Point(261, 22);
            this.izin1CheckBox.Name = "izin1CheckBox";
            this.izin1CheckBox.Size = new System.Drawing.Size(42, 17);
            this.izin1CheckBox.TabIndex = 8;
            this.izin1CheckBox.Text = "Izin";
            this.izin1CheckBox.UseVisualStyleBackColor = true;
            this.izin1CheckBox.CheckedChanged += new System.EventHandler(this.izinChecked);
            // 
            // hadir4CheckBox
            // 
            this.hadir4CheckBox.AutoSize = true;
            this.hadir4CheckBox.Location = new System.Drawing.Point(204, 127);
            this.hadir4CheckBox.Name = "hadir4CheckBox";
            this.hadir4CheckBox.Size = new System.Drawing.Size(51, 17);
            this.hadir4CheckBox.TabIndex = 7;
            this.hadir4CheckBox.Text = "Hadir";
            this.hadir4CheckBox.UseVisualStyleBackColor = true;
            this.hadir4CheckBox.CheckedChanged += new System.EventHandler(this.hadirChecked);
            // 
            // hadir3CheckBox
            // 
            this.hadir3CheckBox.AutoSize = true;
            this.hadir3CheckBox.Location = new System.Drawing.Point(204, 93);
            this.hadir3CheckBox.Name = "hadir3CheckBox";
            this.hadir3CheckBox.Size = new System.Drawing.Size(51, 17);
            this.hadir3CheckBox.TabIndex = 6;
            this.hadir3CheckBox.Text = "Hadir";
            this.hadir3CheckBox.UseVisualStyleBackColor = true;
            this.hadir3CheckBox.CheckedChanged += new System.EventHandler(this.hadirChecked);
            // 
            // hadir2CheckBox
            // 
            this.hadir2CheckBox.AutoSize = true;
            this.hadir2CheckBox.Location = new System.Drawing.Point(204, 56);
            this.hadir2CheckBox.Name = "hadir2CheckBox";
            this.hadir2CheckBox.Size = new System.Drawing.Size(51, 17);
            this.hadir2CheckBox.TabIndex = 5;
            this.hadir2CheckBox.Text = "Hadir";
            this.hadir2CheckBox.UseVisualStyleBackColor = true;
            this.hadir2CheckBox.CheckedChanged += new System.EventHandler(this.hadirChecked);
            // 
            // hadir1CheckBox
            // 
            this.hadir1CheckBox.AutoSize = true;
            this.hadir1CheckBox.Location = new System.Drawing.Point(204, 22);
            this.hadir1CheckBox.Name = "hadir1CheckBox";
            this.hadir1CheckBox.Size = new System.Drawing.Size(51, 17);
            this.hadir1CheckBox.TabIndex = 4;
            this.hadir1CheckBox.Text = "Hadir";
            this.hadir1CheckBox.UseVisualStyleBackColor = true;
            this.hadir1CheckBox.CheckedChanged += new System.EventHandler(this.hadirChecked);
            // 
            // mentee4Box
            // 
            this.mentee4Box.Location = new System.Drawing.Point(6, 125);
            this.mentee4Box.Name = "mentee4Box";
            this.mentee4Box.ReadOnly = true;
            this.mentee4Box.Size = new System.Drawing.Size(180, 20);
            this.mentee4Box.TabIndex = 3;
            // 
            // mentee3Box
            // 
            this.mentee3Box.Location = new System.Drawing.Point(6, 90);
            this.mentee3Box.Name = "mentee3Box";
            this.mentee3Box.ReadOnly = true;
            this.mentee3Box.Size = new System.Drawing.Size(180, 20);
            this.mentee3Box.TabIndex = 2;
            // 
            // mentee2Box
            // 
            this.mentee2Box.Location = new System.Drawing.Point(6, 54);
            this.mentee2Box.Name = "mentee2Box";
            this.mentee2Box.ReadOnly = true;
            this.mentee2Box.Size = new System.Drawing.Size(180, 20);
            this.mentee2Box.TabIndex = 1;
            // 
            // mentee1Box
            // 
            this.mentee1Box.Location = new System.Drawing.Point(6, 19);
            this.mentee1Box.Name = "mentee1Box";
            this.mentee1Box.ReadOnly = true;
            this.mentee1Box.Size = new System.Drawing.Size(180, 20);
            this.mentee1Box.TabIndex = 0;
            // 
            // tanggalLabel
            // 
            this.tanggalLabel.AutoSize = true;
            this.tanggalLabel.Location = new System.Drawing.Point(333, 29);
            this.tanggalLabel.Name = "tanggalLabel";
            this.tanggalLabel.Size = new System.Drawing.Size(46, 13);
            this.tanggalLabel.TabIndex = 6;
            this.tanggalLabel.Text = "Tanggal";
            // 
            // beritaAcaraLabel
            // 
            this.beritaAcaraLabel.AutoSize = true;
            this.beritaAcaraLabel.Location = new System.Drawing.Point(12, 251);
            this.beritaAcaraLabel.Name = "beritaAcaraLabel";
            this.beritaAcaraLabel.Size = new System.Drawing.Size(65, 13);
            this.beritaAcaraLabel.TabIndex = 7;
            this.beritaAcaraLabel.Text = "Berita Acara";
            // 
            // beritaAcaraBox
            // 
            this.beritaAcaraBox.Location = new System.Drawing.Point(15, 267);
            this.beritaAcaraBox.Name = "beritaAcaraBox";
            this.beritaAcaraBox.Size = new System.Drawing.Size(473, 38);
            this.beritaAcaraBox.TabIndex = 8;
            this.beritaAcaraBox.Text = "";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(413, 319);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 23);
            this.submitButton.TabIndex = 9;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitClicked);
            // 
            // TahunComboBox
            // 
            this.TahunComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TahunComboBox.FormattingEnabled = true;
            this.TahunComboBox.Items.AddRange(new object[] {
            "2016"});
            this.TahunComboBox.Location = new System.Drawing.Point(434, 45);
            this.TahunComboBox.Name = "TahunComboBox";
            this.TahunComboBox.Size = new System.Drawing.Size(54, 21);
            this.TahunComboBox.TabIndex = 10;
            // 
            // bulanComboBox
            // 
            this.bulanComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bulanComboBox.FormattingEnabled = true;
            this.bulanComboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.bulanComboBox.Location = new System.Drawing.Point(385, 45);
            this.bulanComboBox.Name = "bulanComboBox";
            this.bulanComboBox.Size = new System.Drawing.Size(43, 21);
            this.bulanComboBox.TabIndex = 11;
            // 
            // hariComboBox
            // 
            this.hariComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hariComboBox.FormattingEnabled = true;
            this.hariComboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.hariComboBox.Location = new System.Drawing.Point(336, 45);
            this.hariComboBox.Name = "hariComboBox";
            this.hariComboBox.Size = new System.Drawing.Size(43, 21);
            this.hariComboBox.TabIndex = 12;
            // 
            // laporanButton
            // 
            this.laporanButton.Location = new System.Drawing.Point(12, 319);
            this.laporanButton.Name = "laporanButton";
            this.laporanButton.Size = new System.Drawing.Size(94, 23);
            this.laporanButton.TabIndex = 13;
            this.laporanButton.Text = "Lihat Laporan";
            this.laporanButton.UseVisualStyleBackColor = true;
            this.laporanButton.Click += new System.EventHandler(this.laporanButtonClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemToolStripMenuItem,
            this.tentangToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(505, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sistemToolStripMenuItem
            // 
            this.sistemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.keluarToolStripMenuItem});
            this.sistemToolStripMenuItem.Name = "sistemToolStripMenuItem";
            this.sistemToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.sistemToolStripMenuItem.Text = "Sistem";
            // 
            // keluarToolStripMenuItem
            // 
            this.keluarToolStripMenuItem.Name = "keluarToolStripMenuItem";
            this.keluarToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.keluarToolStripMenuItem.Text = "Keluar";
            this.keluarToolStripMenuItem.Click += new System.EventHandler(this.keluarClicked);
            // 
            // tentangToolStripMenuItem
            // 
            this.tentangToolStripMenuItem.Name = "tentangToolStripMenuItem";
            this.tentangToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.tentangToolStripMenuItem.Text = "Tentang";
            this.tentangToolStripMenuItem.Click += new System.EventHandler(this.tentangClicked);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(117, 319);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(79, 23);
            this.resetButton.TabIndex = 15;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButtonClicked);
            // 
            // mainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 359);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.laporanButton);
            this.Controls.Add(this.hariComboBox);
            this.Controls.Add(this.bulanComboBox);
            this.Controls.Add(this.TahunComboBox);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.beritaAcaraBox);
            this.Controls.Add(this.beritaAcaraLabel);
            this.Controls.Add(this.tanggalLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.mentorLabel);
            this.Controls.Add(this.mentorComboBox);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainMenu";
            this.Text = "Administrasi Mentoring";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox mentorComboBox;
        private System.Windows.Forms.Label mentorLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox izin4CheckBox;
        private System.Windows.Forms.CheckBox izin3CheckBox;
        private System.Windows.Forms.CheckBox izin2CheckBox;
        private System.Windows.Forms.CheckBox izin1CheckBox;
        private System.Windows.Forms.CheckBox hadir4CheckBox;
        private System.Windows.Forms.CheckBox hadir3CheckBox;
        private System.Windows.Forms.CheckBox hadir2CheckBox;
        private System.Windows.Forms.CheckBox hadir1CheckBox;
        private System.Windows.Forms.TextBox mentee4Box;
        private System.Windows.Forms.TextBox mentee3Box;
        private System.Windows.Forms.TextBox mentee2Box;
        private System.Windows.Forms.TextBox mentee1Box;
        private System.Windows.Forms.TextBox izinBox4;
        private System.Windows.Forms.TextBox izinBox3;
        private System.Windows.Forms.TextBox izinBox2;
        private System.Windows.Forms.TextBox izinBox1;
        private System.Windows.Forms.Label tanggalLabel;
        private System.Windows.Forms.Label beritaAcaraLabel;
        private System.Windows.Forms.RichTextBox beritaAcaraBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.ComboBox TahunComboBox;
        private System.Windows.Forms.ComboBox bulanComboBox;
        private System.Windows.Forms.ComboBox hariComboBox;
        private System.Windows.Forms.Button laporanButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sistemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem keluarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tentangToolStripMenuItem;
        private System.Windows.Forms.Button resetButton;
    }
}

