﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using save = Mentoring.Properties.Settings;

namespace Mentoring
{
    public partial class mainMenu : Form
    {
        public mainMenu()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            toolTipGen();

            mentee1Box.ReadOnly = true;
            mentee2Box.ReadOnly = true;
            mentee3Box.ReadOnly = true;
            mentee4Box.ReadOnly = true;

            izinBox1.ReadOnly = true;
            izinBox2.ReadOnly = true;
            izinBox3.ReadOnly = true;
            izinBox4.ReadOnly = true;
        }

        public string laporan = save.Default.uLaporanSave;
        public string laporanSementara;
        public string a1 = "Adibta Triantama";
        public string a2 = "Labib Hidayaturrohman";
        public string a3 = "Muhammad Husain";
        public string a4 = "Rahdyan Syahirul Alim";
        public string b1 = "Abidzar Afif";
        public string b2 = "Luthfi Afandi Sutrisno";
        public string b3 = "Muhammad Abirafdi";
        public string b4 = "Raden Adji Suryo Utomo";
        protected internal tentangForm tentang = new tentangForm();
        //protected internal reportForm laporanForm = new reportForm();

        private void toolTipGen()
        {
            ToolTip mentorToolTip = new ToolTip();
            mentorToolTip.ShowAlways = true;
            mentorToolTip.SetToolTip(mentorComboBox, "Pilih nama mentor");
            ToolTip tanggalToolTip = new ToolTip();
            tanggalToolTip.ShowAlways = true;
            tanggalToolTip.SetToolTip(tanggalLabel, "Isikan tanggal mentoring");
            ToolTip mentee1ToolTip = new ToolTip();
            mentee1ToolTip.ShowAlways = true;
            mentee1ToolTip.SetToolTip(mentee1Box, "Nama Mentee");
            ToolTip mentee2ToolTip = new ToolTip();
            mentee2ToolTip.ShowAlways = true;
            mentee2ToolTip.SetToolTip(mentee2Box, "Nama Mentee");
            ToolTip mentee3ToolTip = new ToolTip();
            mentee3ToolTip.ShowAlways = true;
            mentee3ToolTip.SetToolTip(mentee3Box, "Nama Mentee");
            ToolTip mentee4ToolTip = new ToolTip();
            mentee4ToolTip.ShowAlways = true;
            mentee4ToolTip.SetToolTip(mentee4Box, "Nama Mentee");
            ToolTip hadir1ToolTip = new ToolTip();
            hadir1ToolTip.ShowAlways = true;
            hadir1ToolTip.SetToolTip(hadir1CheckBox, "Centang apabila hadir");
            ToolTip hadir2ToolTip = new ToolTip();
            hadir2ToolTip.ShowAlways = true;
            hadir2ToolTip.SetToolTip(hadir2CheckBox, "Centang apabila hadir");
            ToolTip hadir3ToolTip = new ToolTip();
            hadir3ToolTip.ShowAlways = true;
            hadir3ToolTip.SetToolTip(hadir3CheckBox, "Centang apabila hadir");
            ToolTip hadir4ToolTip = new ToolTip();
            hadir4ToolTip.ShowAlways = true;
            hadir4ToolTip.SetToolTip(hadir4CheckBox, "Centang apabila hadir");
            ToolTip izin1ToolTip = new ToolTip();
            izin1ToolTip.ShowAlways = true;
            izin1ToolTip.SetToolTip(izin1CheckBox, "Centang apabila izin");
            ToolTip izin2ToolTip = new ToolTip();
            izin2ToolTip.ShowAlways = true;
            izin2ToolTip.SetToolTip(izin2CheckBox, "Centang apabila izin");
            ToolTip izin3ToolTip = new ToolTip();
            izin3ToolTip.ShowAlways = true;
            izin3ToolTip.SetToolTip(izin3CheckBox, "Centang apabila izin");
            ToolTip izin4ToolTip = new ToolTip();
            izin4ToolTip.ShowAlways = true;
            izin4ToolTip.SetToolTip(izin4CheckBox, "Centang apabila izin");
            ToolTip alasan1ToolTip = new ToolTip();
            alasan1ToolTip.ShowAlways = true;
            alasan1ToolTip.SetToolTip(izinBox1, "Alasan mengapa izin");
            ToolTip alasan2ToolTip = new ToolTip();
            alasan2ToolTip.ShowAlways = true;
            alasan2ToolTip.SetToolTip(izinBox2, "Alasan mengapa izin");
            ToolTip alasan3ToolTip = new ToolTip();
            alasan3ToolTip.ShowAlways = true;
            alasan3ToolTip.SetToolTip(izinBox3, "Alasan mengapa izin");
            ToolTip alasan4ToolTip = new ToolTip();
            alasan4ToolTip.ShowAlways = true;
            alasan4ToolTip.SetToolTip(izinBox4, "Alasan mengapa izin");
            ToolTip acaraToolTip = new ToolTip();
            acaraToolTip.ShowAlways = true;
            acaraToolTip.SetToolTip(beritaAcaraLabel, "Isikan berita acara mentoring : Materi yang disampaikan, situasi dan kondisi mentoring, dll.");
            ToolTip submitToolTip = new ToolTip();
            submitToolTip.ShowAlways = true;
            submitToolTip.SetToolTip(submitButton, "Tekan untuk men-submit data");
            ToolTip laporanToolTip = new ToolTip();
            laporanToolTip.ShowAlways = true;
            laporanToolTip.SetToolTip(laporanButton, "Tekan untuk melihat laporan administrasi mentoring");
        }

        private void isiLaporan(string mentor, string a, string b, string c, string d)
        {
            laporanSementara = "[" + mentor + " ";
            laporanSementara += hariComboBox.Text;
            switch (bulanComboBox.Text)
            {
                case "1": laporanSementara += " Januari "; break;
                case "2": laporanSementara += " Februari "; break;
                case "3": laporanSementara += " Maret "; break;
                case "4": laporanSementara += " April "; break;
                case "5": laporanSementara += " Mei "; break;
                case "6": laporanSementara += " Juni "; break;
                case "7": laporanSementara += " Juli "; break;
                case "8": laporanSementara += " Agustus "; break;
                case "9": laporanSementara += " September "; break;
                case "10": laporanSementara += " Oktober "; break;
                case "11": laporanSementara += " November "; break;
                case "12": laporanSementara += " Desember "; break;
            }
            laporanSementara += TahunComboBox.Text + "]\n";
            if (hadir1CheckBox.Checked)
            {
                laporanSementara += "1. " + a + " (Hadir)\n";
            }
            else
            {
                laporanSementara += "1. " + a + " (izin) : " + izinBox1.Text + "\n";
            }
            if (hadir2CheckBox.Checked)
            {
                laporanSementara += "2. " + b + " (Hadir)\n";
            }
            else
            {
                laporanSementara += "2. " + b + " (izin) : " + izinBox2.Text + "\n";
            }
            if (hadir3CheckBox.Checked)
            {
                laporanSementara += "3. " + c + " (Hadir)\n";
            }
            else
            {
                laporanSementara += "3. " + c + " (izin) : " + izinBox3.Text + "\n";
            }
            if (hadir4CheckBox.Checked)
            {
                laporanSementara += "4. " + d + " (Hadir)\n";
            }
            else
            {
                laporanSementara += "4. " + d + " (izin) : " + izinBox4.Text + "\n";
            }
            laporanSementara += "Berita acara : \n" + beritaAcaraBox.Text + "\n";
        }

        private void mentorComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (mentorComboBox.Text == "Arya Albana")
            {
                mentee1Box.Text = a1;
                mentee2Box.Text = a2;
                mentee3Box.Text = a3;
                mentee4Box.Text = a4;
            }
            else if (mentorComboBox.Text == "Imam Santoso")
            {
                mentee1Box.Text = b1;
                mentee2Box.Text = b2;
                mentee3Box.Text = b3;
                mentee4Box.Text = b4;
            }
            else
            {
                mentee1Box.Text = "";
                mentee2Box.Text = "";
                mentee3Box.Text = "";
                mentee4Box.Text = "";
            }
        }

        private void hadirChecked(object sender, EventArgs e)
        {
            if (hadir1CheckBox.Checked)
            {
                izin1CheckBox.Checked = false;
                izinBox1.Text = "";
                izinBox1.ReadOnly = true;
            }

            if (hadir2CheckBox.Checked)
            {
                izin2CheckBox.Checked = false;
                izinBox2.Text = "";
                izinBox2.ReadOnly = true;
            }

            if (hadir3CheckBox.Checked)
            {
                izin3CheckBox.Checked = false;
                izinBox3.Text = "";
                izinBox3.ReadOnly = true;
            }

            if (hadir4CheckBox.Checked)
            {
                izin4CheckBox.Checked = false;
                izinBox4.Text = "";
                izinBox4.ReadOnly = true;
            }
        }

        private void izinChecked(object sender, EventArgs e)
        {
            if (izin1CheckBox.Checked)
            {
                hadir1CheckBox.Checked = false;
                izinBox1.ReadOnly = false;
                
            }

            if (izin2CheckBox.Checked)
            {
                hadir2CheckBox.Checked = false;
                izinBox2.ReadOnly = false;
            }

            if (izin3CheckBox.Checked)
            {
                hadir3CheckBox.Checked = false;
                izinBox3.ReadOnly = false;
            }

            if (izin4CheckBox.Checked)
            {
                hadir4CheckBox.Checked = false;
                izinBox4.ReadOnly = false;
            }
        }

        private void submitClicked(object sender, EventArgs e)
        {
            if (mentorComboBox.Text == "")
            {
                MessageBox.Show("Nama Mentor Tidak Boleh Kosong!","Error");
            }
            else if (hariComboBox.Text == "" || bulanComboBox.Text == "" || TahunComboBox.Text == "")
            {
                MessageBox.Show("Tanggal Mentoring tidak boleh kosong!", "Error");
            }
            else if ((hariComboBox.Text=="31" &&(bulanComboBox.Text=="2"||bulanComboBox.Text=="4"||bulanComboBox.Text=="6"|| bulanComboBox.Text == "9"|| bulanComboBox.Text == "11")) || (hariComboBox.Text=="30" && bulanComboBox.Text == "2") || (hariComboBox.Text=="29" && bulanComboBox.Text=="2" &&(Convert.ToInt32(TahunComboBox.Text)%4!=0)))
            {
                MessageBox.Show("Pengisian Tanggal Jangan Bercanda!", "Error");
            }
            else if (!((hadir1CheckBox.Checked||izin1CheckBox.Checked)&& (hadir2CheckBox.Checked || izin2CheckBox.Checked)&& (hadir3CheckBox.Checked || izin3CheckBox.Checked)&& (hadir4CheckBox.Checked || izin4CheckBox.Checked)))
            {
                MessageBox.Show("Presensi mentee belum diisi dengan lengkap!", "Error");
            }
            else if ((izin1CheckBox.Checked && izinBox1.Text == "") || (izin2CheckBox.Checked && izinBox2.Text == "") || (izin3CheckBox.Checked && izinBox3.Text == "") || (izin4CheckBox.Checked && izinBox4.Text == ""))
            {
                MessageBox.Show("Izin harus dengan alasan yang jelas!", "Error");
            }
            else if (beritaAcaraBox.Text=="")
            {
                MessageBox.Show("Berita acara tidak boleh kosong!", "Error");
            }
            else
            {
                if (MessageBox.Show("Apakah data yang anda isikan sudah benar?","",MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    laporanSementara = "";
                    if (mentorComboBox.Text == "Arya Albana")
                    {
                        isiLaporan("Arya Albana", a1, a2, a3, a4);
                    }
                    else
                    {
                        isiLaporan("Imam Santosa", b1, b2, b3, b4);
                    }
                    laporan = laporanSementara + "\n" + laporan;
                    save.Default.uLaporanSave = laporan;
                    save.Default.Save();
                    MessageBox.Show("Laporan anda telah direkam!");
                    inputReset();
                }
            }
        }

       
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
            if (MessageBox.Show("Apakah anda ingin keluar?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
               // save.Default.Save();
                Application.ExitThread();
                Application.Exit();
            }
            else
            {
                e.Cancel = true;
            }

        }

        private void tentangClicked(object sender, EventArgs e)
        {
            tentang.Show();
            tentang.Focus();
          //  tentang.senderForm = this;
        }

        private void keluarClicked(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah anda ingin keluar?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //save.Default.Save();
                Application.ExitThread();
                Application.Exit();
            }
        }

        private void laporanButtonClicked(object sender, EventArgs e)
        {
            reportForm laporanForm = new reportForm();
            laporanForm.Show();
            laporanForm.Focus();
        }

        private void resetButtonClicked(object sender, EventArgs e)
        {
            if(MessageBox.Show("Anda akan menghapus semua rekaman data, apakah anda yakin?","Peringatan",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                laporan = "";
                save.Default.uLaporanSave = laporan;
                save.Default.Save();
                MessageBox.Show("Rekaman data berhasil dihapus");
            }
        }
        private void inputReset()
        {
            mentorComboBox.Text = "";
            hariComboBox.Text = "";
            bulanComboBox.Text = "";
            TahunComboBox.Text = "";
            mentee1Box.Text = "";
            mentee2Box.Text = "";
            mentee3Box.Text =  "";
            mentee4Box.Text = "";
            hadir1CheckBox.Checked = false;
            hadir2CheckBox.Checked = false;
            hadir3CheckBox.Checked = false;
            hadir4CheckBox.Checked = false;
            izin1CheckBox.Checked = false;
            izin2CheckBox.Checked = false;
            izin3CheckBox.Checked = false;
            izin4CheckBox.Checked = false;
            izinBox1.Text = "";
            izinBox2.Text = "";
            izinBox3.Text = "";
            izinBox4.Text = "";
            beritaAcaraBox.Text = "";
        }
    }
}
